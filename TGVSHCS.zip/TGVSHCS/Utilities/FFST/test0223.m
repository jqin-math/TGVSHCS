%% This demo is to apply HF-guided shearlet based recon.
% Jing, 2-23-2012
clear;close all; clc;

%% Load the image and produce k-space data
n = 128;
I = phantom(n); I = abs(I)./range(I(:));
B = fft2(I);

%beam = 20;
%p = double(MRImask(n,beam));
%p = ifftshift(p);

p = ones(n,n);

b = p.*B;

%% Step 1: Bandwise recon.
L = 2;
nsh = 2^(L+2)-3;
para.tau    = 1e-6*ones(nsh,1);
para.gamma  = 1e-4*ones(nsh,1);
para.lambda = 1e-12*ones(nsh,1);
para.maxiter= 100;
para.shearlevel = L;

[X,~,erriter] = SHBW2D_FFST(p,b,para,I);

figure
for i = 1:nsh
    subplot(2,ceil(nsh/2),i)
    plot(erriter(i,:),'.-','Markersize',15)
end


%% Step 2: SH guided recon.
para.alpha  = 1e-6*ones(nsh,1);
para.mu     = 1e-3;
para.beta   = 1e-2;
para.gamma  = 1e-3;
para.maxiter= 250;
y = SHTVHF2D_FFST(X,p,b,para);

%% Step 3: Display the result
figure
imagesc(abs(y)); axis image off; colormap gray