% This demo is to obtain the designed kernels
% By Jing, 2-23-2012
clear;close all;clc;
A = phantom(128);
N = size(A);
L = 1;
shearlet_spect = 'meyerShearletSpect';
shearlet_arg   = [];
Psi = scalesShearsAndSpectra(N,L,shearlet_spect,shearlet_arg);

TA = Psi.*repmat(fftshift(fft2(A)),[1,1,size(Psi,3)]);
ST = ifft2(fftshift(fftshift(TA,1),2));


figure;
k = size(ST,3);
for i = 1:k
    subplot(2,k/2,i)
    imagesc(abs(Psi(:,:,i))); axis image off; colormap gray
end